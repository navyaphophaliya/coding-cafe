window.__THAR_CONFIG = {
  "userInfo": {
    "accountId": "1000000001",
    "userName": "jsmith_demo",
    "displayName": "Joe Smith"
  },
  "archiveInfo": {
    "sizeBytes": "237932041",
    "generationDate": "2024-09-12T18:58:30.794Z",
    "isPartialArchive": false,
    "maxPartSizeBytes": "53687091200"
  },
  "readmeInfo": {
    "fileName": "data/README.txt",
    "directory": "data/",
    "name": "README.txt"
  },
  "dataTypes": {
    "account": {
      "files": [
        {
          "fileName": "data/account.js",
          "globalName": "YTD.account.part0",
          "count": "1"
        }
      ]
    },
    "accountCreationIp": {
      "files": [
        {
          "fileName": "data/account-creation-ip.js",
          "globalName": "YTD.account_creation_ip.part0",
          "count": "1"
        }
      ]
    },
    "accountLabel": {
      "files": [
        {
          "fileName": "data/account-label.js",
          "globalName": "YTD.account_label.part0",
          "count": "1"
        }
      ]
    },
    "accountSuspension": {
      "files": [
        {
          "fileName": "data/account-suspension.js",
          "globalName": "YTD.account_suspension.part0",
          "count": "0"
        }
      ]
    },
    "accountTimezone": {
      "files": [
        {
          "fileName": "data/account-timezone.js",
          "globalName": "YTD.account_timezone.part0",
          "count": "1"
        }
      ]
    },
    "adEngagements": {
      "files": [
        {
          "fileName": "data/ad-engagements.js",
          "globalName": "YTD.ad_engagements.part0",
          "count": "17"
        }
      ]
    },
    "adImpressions": {
      "files": [
        {
          "fileName": "data/ad-impressions.js",
          "globalName": "YTD.ad_impressions.part0",
          "count": "0"
        }
      ]
    },
    "adMobileConversionsAttributed": {
      "files": [
        {
          "fileName": "data/ad-mobile-conversions-attributed.js",
          "globalName": "YTD.ad_mobile_conversions_attributed.part0",
          "count": "24"
        }
      ]
    },
    "adMobileConversionsUnattributed": {
      "files": [
        {
          "fileName": "data/ad-mobile-conversions-unattributed.js",
          "globalName": "YTD.ad_mobile_conversions_unattributed.part0",
          "count": "14"
        }
      ]
    },
    "adOnlineConversionsAttributed": {
      "files": [
        {
          "fileName": "data/ad-online-conversions-attributed.js",
          "globalName": "YTD.ad_online_conversions_attributed.part0",
          "count": "9"
        }
      ]
    },
    "adOnlineConversionsUnattributed": {
      "files": [
        {
          "fileName": "data/ad-online-conversions-unattributed.js",
          "globalName": "YTD.ad_online_conversions_unattributed.part0",
          "count": "0"
        }
      ]
    },
    "adsRevenueSharing": {
      "files": [
        {
          "fileName": "data/ads-revenue-sharing.js",
          "globalName": "YTD.ads_revenue_sharing.part0",
          "count": "1"
        }
      ]
    },
    "ageinfo": {
      "files": [
        {
          "fileName": "data/ageinfo.js",
          "globalName": "YTD.ageinfo.part0",
          "count": "1"
        }
      ]
    },
    "app": {
      "files": [
        {
          "fileName": "data/app.js",
          "globalName": "YTD.app.part0",
          "count": "9"
        }
      ]
    },
    "article": {
      "files": [
        {
          "fileName": "data/article.js",
          "globalName": "YTD.article.part0",
          "count": "0"
        }
      ]
    },
    "articleMetadata": {
      "files": [
        {
          "fileName": "data/article-metadata.js",
          "globalName": "YTD.article_metadata.part0",
          "count": "0"
        }
      ]
    },
    "block": {
      "files": [
        {
          "fileName": "data/block.js",
          "globalName": "YTD.block.part0",
          "count": "3"
        }
      ]
    },
    "branchLinks": {
      "files": [
        {
          "fileName": "data/branch-links.js",
          "globalName": "YTD.branch_links.part0",
          "count": "0"
        }
      ]
    },
    "catalogItem": {
      "files": [
        {
          "fileName": "data/catalog-item.js",
          "globalName": "YTD.catalog_item.part0",
          "count": "0"
        }
      ]
    },
    "commerceCatalog": {
      "files": [
        {
          "fileName": "data/commerce-catalog.js",
          "globalName": "YTD.commerce_catalog.part0",
          "count": "0"
        }
      ]
    },
    "communityNote": {
      "files": [
        {
          "fileName": "data/community-note.js",
          "globalName": "YTD.community_note.part0",
          "count": "0"
        }
      ]
    },
    "communityNoteRating": {
      "files": [
        {
          "fileName": "data/community-note-rating.js",
          "globalName": "YTD.community_note_rating.part0",
          "count": "0"
        }
      ]
    },
    "communityNoteTombstone": {
      "files": [
        {
          "fileName": "data/community-note-tombstone.js",
          "globalName": "YTD.community_note_tombstone.part0",
          "count": "0"
        }
      ]
    },
    "communityTweet": {
      "files": [
        {
          "fileName": "data/community-tweet.js",
          "globalName": "YTD.community_tweet.part0",
          "count": "0"
        }
      ]
    },
    "communityTweetMedia": {},
    "connectedApplication": {
      "files": [
        {
          "fileName": "data/connected-application.js",
          "globalName": "YTD.connected_application.part0",
          "count": "4"
        }
      ]
    },
    "contact": {
      "files": [
        {
          "fileName": "data/contact.js",
          "globalName": "YTD.contact.part0",
          "count": "40"
        }
      ]
    },
    "deletedNoteTweet": {
      "files": [
        {
          "fileName": "data/deleted-note-tweet.js",
          "globalName": "YTD.deleted_note_tweet.part0",
          "count": "0"
        }
      ]
    },
    "deletedTweetHeaders": {
      "files": [
        {
          "fileName": "data/deleted-tweet-headers.js",
          "globalName": "YTD.deleted_tweet_headers.part0",
          "count": "0"
        }
      ]
    },
    "deletedTweets": {
      "files": [
        {
          "fileName": "data/deleted-tweets.js",
          "globalName": "YTD.deleted_tweets.part0",
          "count": "0"
        }
      ]
    },
    "deletedTweetsMedia": {},
    "deviceToken": {
      "files": [
        {
          "fileName": "data/device-token.js",
          "globalName": "YTD.device_token.part0",
          "count": "5"
        }
      ]
    },
    "directMessageGroupHeaders": {
      "files": [
        {
          "fileName": "data/direct-message-group-headers.js",
          "globalName": "YTD.direct_message_group_headers.part0",
          "count": "9"
        }
      ]
    },
    "directMessageHeaders": {
      "files": [
        {
          "fileName": "data/direct-message-headers.js",
          "globalName": "YTD.direct_message_headers.part0",
          "count": "24"
        }
      ]
    },
    "directMessageMute": {
      "files": [
        {
          "fileName": "data/direct-message-mute.js",
          "globalName": "YTD.direct_message_mute.part0",
          "count": "0"
        }
      ]
    },
    "directMessages": {
      "files": [
        {
          "fileName": "data/direct-messages.js",
          "globalName": "YTD.direct_messages.part0",
          "count": "20"
        }
      ]
    },
    "directMessagesGroup": {
      "files": [
        {
          "fileName": "data/direct-messages-group.js",
          "globalName": "YTD.direct_messages_group.part0",
          "count": "6"
        }
      ]
    },
    "directMessagesGroupMedia": {},
    "directMessagesMedia": {},
    "emailAddressChange": {
      "files": [
        {
          "fileName": "data/email-address-change.js",
          "globalName": "YTD.email_address_change.part0",
          "count": "1"
        }
      ]
    },
    "expandedProfile": {
      "files": [
        {
          "fileName": "data/expanded-profile.js",
          "globalName": "YTD.expanded_profile.part0",
          "count": "1"
        }
      ]
    },
    "follower": {
      "files": [
        {
          "fileName": "data/follower.js",
          "globalName": "YTD.follower.part0",
          "count": "59"
        }
      ]
    },
    "following": {
      "files": [
        {
          "fileName": "data/following.js",
          "globalName": "YTD.following.part0",
          "count": "123"
        }
      ]
    },
    "grokChatItem": {
      "files": [
        {
          "fileName": "data/grok-chat-item.js",
          "globalName": "YTD.grok_chat_item.part0",
          "count": "0"
        }
      ]
    },
    "ipAudit": {
      "files": [
        {
          "fileName": "data/ip-audit.js",
          "globalName": "YTD.ip_audit.part0",
          "count": "120"
        }
      ]
    },
    "keyRegistry": {
      "files": [
        {
          "fileName": "data/key-registry.js",
          "globalName": "YTD.key_registry.part0",
          "count": "1"
        }
      ]
    },
    "like": {
      "files": [
        {
          "fileName": "data/like.js",
          "globalName": "YTD.like.part0",
          "count": "300"
        }
      ]
    },
    "listsCreated": {
      "files": [
        {
          "fileName": "data/lists-created.js",
          "globalName": "YTD.lists_created.part0",
          "count": "0"
        }
      ]
    },
    "listsMember": {
      "files": [
        {
          "fileName": "data/lists-member.js",
          "globalName": "YTD.lists_member.part0",
          "count": "0"
        }
      ]
    },
    "listsSubscribed": {
      "files": [
        {
          "fileName": "data/lists-subscribed.js",
          "globalName": "YTD.lists_subscribed.part0",
          "count": "0"
        }
      ]
    },
    "moment": {
      "files": [
        {
          "fileName": "data/moment.js",
          "globalName": "YTD.moment.part0",
          "count": "1"
        }
      ]
    },
    "momentsMedia": {},
    "momentsTweetsMedia": {},
    "mute": {
      "files": [
        {
          "fileName": "data/mute.js",
          "globalName": "YTD.mute.part0",
          "count": "3"
        }
      ]
    },
    "niDevices": {
      "files": [
        {
          "fileName": "data/ni-devices.js",
          "globalName": "YTD.ni_devices.part0",
          "count": "3"
        }
      ]
    },
    "noteTweet": {
      "files": [
        {
          "fileName": "data/note-tweet.js",
          "globalName": "YTD.note_tweet.part0",
          "count": "0"
        }
      ]
    },
    "periscopeAccountInformation": {
      "files": [
        {
          "fileName": "data/periscope-account-information.js",
          "globalName": "YTD.periscope_account_information.part0",
          "count": "1"
        }
      ]
    },
    "periscopeBanInformation": {
      "files": [
        {
          "fileName": "data/periscope-ban-information.js",
          "globalName": "YTD.periscope_ban_information.part0",
          "count": "1"
        }
      ]
    },
    "periscopeBroadcastMetadata": {
      "files": [
        {
          "fileName": "data/periscope-broadcast-metadata.js",
          "globalName": "YTD.periscope_broadcast_metadata.part0",
          "count": "0"
        }
      ]
    },
    "periscopeCommentsMadeByUser": {
      "files": [
        {
          "fileName": "data/periscope-comments-made-by-user.js",
          "globalName": "YTD.periscope_comments_made_by_user.part0",
          "count": "0"
        }
      ]
    },
    "periscopeExpiredBroadcasts": {
      "files": [
        {
          "fileName": "data/periscope-expired-broadcasts.js",
          "globalName": "YTD.periscope_expired_broadcasts.part0",
          "count": "0"
        }
      ]
    },
    "periscopeFollowers": {
      "files": [
        {
          "fileName": "data/periscope-followers.js",
          "globalName": "YTD.periscope_followers.part0",
          "count": "0"
        }
      ]
    },
    "periscopeProfileDescription": {
      "files": [
        {
          "fileName": "data/periscope-profile-description.js",
          "globalName": "YTD.periscope_profile_description.part0",
          "count": "1"
        }
      ]
    },
    "personalization": {
      "files": [
        {
          "fileName": "data/personalization.js",
          "globalName": "YTD.personalization.part0",
          "count": "1"
        }
      ]
    },
    "phoneNumber": {
      "files": [
        {
          "fileName": "data/phone-number.js",
          "globalName": "YTD.phone_number.part0",
          "count": "1"
        }
      ]
    },
    "productDrop": {
      "files": [
        {
          "fileName": "data/product-drop.js",
          "globalName": "YTD.product_drop.part0",
          "count": "0"
        }
      ]
    },
    "productSet": {
      "files": [
        {
          "fileName": "data/product-set.js",
          "globalName": "YTD.product_set.part0",
          "count": "0"
        }
      ]
    },
    "professionalData": {
      "files": [
        {
          "fileName": "data/professional-data.js",
          "globalName": "YTD.professional_data.part0",
          "count": "0"
        }
      ]
    },
    "profile": {
      "files": [
        {
          "fileName": "data/profile.js",
          "globalName": "YTD.profile.part0",
          "count": "1"
        }
      ]
    },
    "profileMedia": {},
    "protectedHistory": {
      "files": [
        {
          "fileName": "data/protected-history.js",
          "globalName": "YTD.protected_history.part0",
          "count": "0"
        }
      ]
    },
    "replyPrompt": {
      "files": [
        {
          "fileName": "data/reply-prompt.js",
          "globalName": "YTD.reply_prompt.part0",
          "count": "0"
        }
      ]
    },
    "savedSearch": {
      "files": [
        {
          "fileName": "data/saved-search.js",
          "globalName": "YTD.saved_search.part0",
          "count": "0"
        }
      ]
    },
    "screenNameChange": {
      "files": [
        {
          "fileName": "data/screen-name-change.js",
          "globalName": "YTD.screen_name_change.part0",
          "count": "0"
        }
      ]
    },
    "shopModule": {
      "files": [
        {
          "fileName": "data/shop-module.js",
          "globalName": "YTD.shop_module.part0",
          "count": "0"
        }
      ]
    },
    "shopifyAccount": {
      "files": [
        {
          "fileName": "data/shopify-account.js",
          "globalName": "YTD.shopify_account.part0",
          "count": "0"
        }
      ]
    },
    "smartblock": {
      "files": [
        {
          "fileName": "data/smartblock.js",
          "globalName": "YTD.smartblock.part0",
          "count": "0"
        }
      ]
    },
    "spacesMetadata": {
      "files": [
        {
          "fileName": "data/spaces-metadata.js",
          "globalName": "YTD.spaces_metadata.part0",
          "count": "0"
        }
      ]
    },
    "sso": {
      "files": [
        {
          "fileName": "data/sso.js",
          "globalName": "YTD.sso.part0",
          "count": "1"
        }
      ]
    },
    "tweetHeaders": {
      "files": [
        {
          "fileName": "data/tweet-headers.js",
          "globalName": "YTD.tweet_headers.part0",
          "count": "250"
        }
      ]
    },
    "tweetdeck": {
      "files": [
        {
          "fileName": "data/tweetdeck.js",
          "globalName": "YTD.tweetdeck.part0",
          "count": "0"
        }
      ]
    },
    "tweets": {
      "files": [
        {
          "fileName": "data/tweets.js",
          "globalName": "YTD.tweets.part0",
          "count": "250"
        }
      ]
    },
    "tweetsMedia": {},
    "twitterShop": {
      "files": [
        {
          "fileName": "data/twitter-shop.js",
          "globalName": "YTD.twitter_shop.part0",
          "count": "0"
        }
      ]
    },
    "userLinkClicks": {
      "files": [
        {
          "fileName": "data/user-link-clicks.js",
          "globalName": "YTD.user_link_clicks.part0",
          "count": "0"
        }
      ]
    },
    "verified": {
      "files": [
        {
          "fileName": "data/verified.js",
          "globalName": "YTD.verified.part0",
          "count": "1"
        }
      ]
    },
    "verifiedOrganization": {
      "files": [
        {
          "fileName": "data/verified-organization.js",
          "globalName": "YTD.verified_organization.part0",
          "count": "1"
        }
      ]
    }
  }
}